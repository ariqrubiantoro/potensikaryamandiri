/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.{html,js}"],
  theme: {
    extend: {
      colors: {
        main: " #7ce609",
      },
      keyframes: {
        progress: {
          "0%": { width: "0%" },
          "100%": { width: "70%" },
        },
        popout: {
          "0%": { opacity: "0%" },
          "100%": { opacity: "100%" },
        },
      },
      animation: {
        progress: "progress 1s ease-in-out",
        popout: "popout 1.5s ease-in-out",
      },
      fontFamily: {
        josefinsans: "Josefin Sans",
        rubik: "Rubik",
      },
    },
  },
  plugins: [],
};
